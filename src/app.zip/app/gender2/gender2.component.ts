import { Component } from '@angular/core';

@Component({
  selector: 'app-gender2',
  templateUrl: './gender2.component.html',
  styleUrls: ['./gender2.component.scss']
})
export class Gender2Component {
  title = 'css-started';
}
